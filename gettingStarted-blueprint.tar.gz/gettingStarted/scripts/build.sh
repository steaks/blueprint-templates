cd server && npm run build && cd ..
cd ui && npm run build && cd ..
