const Home = () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the rectangle area calculation example app.</div>
      <br />
      <a href="/myApp">My App</a>
    </>
  );
};

export default Home;