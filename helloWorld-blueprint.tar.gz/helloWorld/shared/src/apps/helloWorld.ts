//Put shared types between the server and ui here
"use strict";
export {};
