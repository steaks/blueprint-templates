const Home = () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the blueprint hello world template. See the helloWorld app linked below.</div>
      <br />
      <a href="/helloWorld">Hello World</a>
    </>
  );
};

export default Home;