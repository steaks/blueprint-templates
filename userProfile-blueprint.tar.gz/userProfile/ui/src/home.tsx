const Home = () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the blueprint user profile template. See the userProfile app linked below.</div>
      <br />
      <a href="/userProfile">User Profile</a>
    </>
  );
};

export default Home;