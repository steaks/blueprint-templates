export interface User {
  readonly email: string;
  readonly firstName: string;
  readonly lastName: string;
}