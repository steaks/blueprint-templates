# Hello World Template

Use this template to get started with Blueprint.

## Setup

```
1. make install
2. make build
3. make run-server # Run in separate terminal.
4. make run-ui # Run in separate terminal. Open browser to http://localhost:3000
5. make run-blueprint # Run in separate terminal. Open browser to http://localhost:3001
```