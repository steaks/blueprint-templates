cd server && rm -rf node_modules && rm -rf build && rm -rf types && cd ..
cd ui && rm -rf node_modules && rm -rf build && rm -rf types && cd ..
