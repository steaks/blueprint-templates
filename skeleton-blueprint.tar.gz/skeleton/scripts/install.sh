cd server && npm install && cd ..
cd ui && npm install && cd ..
