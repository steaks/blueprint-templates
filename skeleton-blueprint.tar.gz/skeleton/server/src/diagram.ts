import {diagram} from "blueprint-server";
import session from "./session";

diagram({}, session);