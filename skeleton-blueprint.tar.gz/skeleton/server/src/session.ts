import {Session} from "blueprint-server/types";


const session$$ = {
  state: {},
  events: {},
  hooks: {}
} as Session;

export default session$$;