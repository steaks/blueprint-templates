import {Session} from "blueprint-server/types";


const session$$ = {
  state: {},
  events: {},
  tasks: {}
} as Session;

export default session$$;