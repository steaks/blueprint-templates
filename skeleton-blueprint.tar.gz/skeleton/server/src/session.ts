import {Session} from "blueprint-server/types";


const session$$ = {
  state: {},
  events: {},
  queries: {},
  effects: {}
} as Session;

export default session$$;