import React from "react";

const Home = () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the blueprint skeleton template.</div>
      <br/>
      <div>Click <a href="helloWorld">here</a> to open the helloWorld app if you are following the getting started tutorial.</div>
    </>
  );
};

export default Home;