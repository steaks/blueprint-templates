const Home = () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the blueprint skeleton template.</div>
      <br />
    </>
  );
};

export default Home;