export default () => {
  return (
    <>
      <h1>Welcome to Blueprint!</h1>
      <div>This is the blueprint hello world template. In addition to this page a user profile Blueprint App has been created for you.</div>
      <br />
      <a href="/userProfile">User Profile</a>
    </>
  );
}